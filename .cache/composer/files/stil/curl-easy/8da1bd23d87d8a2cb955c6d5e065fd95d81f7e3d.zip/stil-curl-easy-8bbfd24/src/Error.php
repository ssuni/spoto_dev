<?php

namespace cURL;

class Error extends \Exception
{
}
