<?php

use CodeIgniter\Test;

class CIUnitTestCase extends Test\CIUnitTestCase
{

}
